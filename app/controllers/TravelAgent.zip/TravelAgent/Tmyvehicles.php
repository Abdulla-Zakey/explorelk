<?php

    class Tmyvehicles extends Controller {

       
        public function index($a = '', $b = '', $c = ''){

           

            $this->view('travelagent/myvehicles');
            
        }
    }