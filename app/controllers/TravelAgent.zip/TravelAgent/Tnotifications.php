<?php

    class Tnotifications extends Controller {

      
        public function index($a = '', $b = '', $c = ''){

           

            $this->view('travelagent/notifications');
            
        }
    }