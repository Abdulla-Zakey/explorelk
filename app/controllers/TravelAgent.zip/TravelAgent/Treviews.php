<?php

    class Treviews extends Controller{

      
        public function index($a = '', $b = '', $c = ''){

           

            $this->view('travelagent/reviews');
            
        }
    }