<?php

    class Treports extends Controller{

      
        public function index($a = '', $b = '', $c = ''){

           

            $this->view('travelagent/reports');
            
        }
    }