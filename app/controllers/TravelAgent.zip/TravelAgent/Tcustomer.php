<?php

    class Tcustomer extends Controller {

        
        public function index($a = '', $b = '', $c = ''){

           

            $this->view('travelagent/customer');
            
        }
    }